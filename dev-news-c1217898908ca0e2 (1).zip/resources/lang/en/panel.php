<?php

return [
    'site_title' => 'news',
];
